// connection.js

function good_login() {
    // demo log
    var usernameInput = document.getElementById('username').value;
    var passwordInput = document.getElementById('password').value;
  
    // Hardcoded username and password for demonstration purposes
    var hardcodedUsername = 'a';
    var hardcodedPassword = 'a';
  
    // Check if the entered credentials match the hardcoded values
    if (usernameInput === hardcodedUsername && passwordInput === hardcodedPassword) {
      // Set a session flag to indicate the user is logged in
      sessionStorage.setItem('isLoggedIn', 'true');

      // Redirect to home.html if credentials match
      window.location.href = '../home/home.html';

      // Use replaceState to clear the browser history
      history.replaceState(null, '', '../home/home.html');

      return false; // Prevent form submission
  } else {
      // Display an alert for demonstration (replace with actual error handling)
      alert('Invalid username or password');
      return false; // Prevent form submission
  }
}

  function toggleDropdown() {
    var dropdownContent = document.getElementById('dropdownContent');
    dropdownContent.style.display = (dropdownContent.style.display === 'block') ? 'none' : 'block';
  }

  function closeDropdown() {
    var dropdownContent = document.getElementById('dropdownContent');
    dropdownContent.style.display = 'none';
  }

  function selectRole(role) {
    if (role === 'Student') {
      window.location.href = 'index.html';
    } else if (role === 'Teacher') {
      window.location.href = 'admin.html';
    }
    else
    {
      window.location.href = 'admin.html';
    }
  }

// Function to handle logout
function logout() {
  // Remove the session flag to indicate the user is logged out
  sessionStorage.removeItem('isLoggedIn');

  // Use replaceState to clear the browser history and redirect to index.html
  history.replaceState(null, '', 'index.html');

  // Redirect to index.html on logout
  window.location.href = 'index.html';
}


$(document).ready(function () {
  $("#menu-toggle").click(function (e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
  });
});