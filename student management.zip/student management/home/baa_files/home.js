var swiper3 = new Swiper('.swiper3', {
     slidesPerView: 1, spaceBetween: 0, 
     loop: true, 
     effect: 'cube',
      grabCursor: true,
      cubeEffect: {
        shadow: true,
        slideShadows: true,
        shadowOffset: 20,
        shadowScale: 0.94,
      },
     autoplay: {
        delay: 4500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination3',
        clickable: true, 
      },
      navigation: {
        nextEl: '.swiper3-next',
        prevEl: '.swiper3-prev',
      },
      breakpoints: {360: { slidesPerView: 1, spaceBetween: 0},
        480: {slidesPerView: 1, spaceBetween: 0},
        640: {slidesPerView: 1, spaceBetween: 0}
      },
    });

var swiper4 = new Swiper('.swiper4', {
     slidesPerView: 2, spaceBetween: 40, 
     loop: true, 
     autoplay: {
        delay: 4500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination4',
        clickable: true, 
      },
      navigation: {
        nextEl: '.swiper4-next',
        prevEl: '.swiper4-prev',
      },
      breakpoints: {360: { slidesPerView: 1, spaceBetween: 0},
        480: {slidesPerView: 1, spaceBetween: 20},
        640: {slidesPerView: 2, spaceBetween: 30}
      },
    });


var swiper5 = new Swiper('.swiper5', {
     slidesPerView: 4, spaceBetween: 40, 
     loop: true, 
     autoplay: {
        delay: 4500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination5',
        clickable: true, 
      },
      navigation: {
        nextEl: '.swiper5-next',
        prevEl: '.swiper5-prev',
      },
      breakpoints: {360: { slidesPerView: 1, spaceBetween: 0},
        480: {slidesPerView: 2, spaceBetween: 20},
        640: {slidesPerView: 4, spaceBetween: 30}
      },
    });

var swiper6 = new Swiper('.swiper6', {
     slidesPerView: 4, spaceBetween: 30, 
     loop: true, 
     autoplay: {
        delay: 4500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination6',
        clickable: true, 
      },
      navigation: {
        nextEl: '.swiper6-next',
        prevEl: '.swiper6-prev',
      },
      breakpoints: {360: { slidesPerView: 1, spaceBetween: 0},
        480: {slidesPerView: 2, spaceBetween: 20},
        640: {slidesPerView: 4, spaceBetween: 30}
      },
    });

$(".swiper-container").hover(function() {
    (this).swiper.autoplay.stop();
}, function() {
    (this).swiper.autoplay.start();
});